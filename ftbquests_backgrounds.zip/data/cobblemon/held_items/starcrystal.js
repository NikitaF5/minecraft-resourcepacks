({
    name: "Star Crystal",
    onBasePowerPriority: 15,
    onBasePower(basePower, user, target, move) {
      if (user.baseSpecies.num === 399 && (move.type === "Dragon" || move.type === "Fairy")) {
        return this.chainModify([4915, 4096]);
      }
    },
    onTakeItem(item, pokemon, source) {
      if (source?.baseSpecies.num === 399 || pokemon.baseSpecies.num === 399) {
        return false;
      }
      return true;
    },
    num: 73691,
})
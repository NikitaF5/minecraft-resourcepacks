({
    onDamagingHit(damage, target, source, move) {
      this.field.setWeather("snow");
    },
    flags: {},
    name: "Snow Call",
    rating: 1
  })
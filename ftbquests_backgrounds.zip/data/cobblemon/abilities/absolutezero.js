({
    onModifyAtkPriority: 5,
    onModifyAtk(atk, pokemon) {
      if (["snow", "hail"].includes(pokemon.effectiveWeather())) {
        return this.chainModify(1.5);
      }
    },
    onWeather(target, source, effect) {
      if (target.hasItem("utilityumbrella"))
        return;
      if (effect.id === "snow" || effect.id === "hail") {
        this.damage(target.baseMaxhp / 8, target, target);
      }
    },
    flags: {},
    name: "Absolute Zero",
    rating: 2
  })
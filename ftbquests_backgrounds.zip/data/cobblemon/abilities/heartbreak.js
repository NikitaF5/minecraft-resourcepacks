({
    onModifyCritRatio(critRatio, source, target) {
      if (target && pokemon.volatiles["attract"])
        return 5;
    },
    flags: {},
    name: "Heartbreak",
    rating: 1.5
  })
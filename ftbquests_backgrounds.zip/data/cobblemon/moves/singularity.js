({  num: 640025,
    accuracy: 100,
    basePower: 120,
    category: "Special",
    name: "Singularity",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    self: {
      pseudoWeather: "gravity",
      boosts: {
        spa: -1
      }
    },
    target: "allAdjacent",
    type: "Ghost",
    contestType: "Tough"
  })
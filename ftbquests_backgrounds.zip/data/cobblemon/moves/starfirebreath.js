({  num: 640028,
    accuracy: 80,
    basePower: 110,
    category: "Special",
    name: "Starfire Breath",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 10,
      status: "brn"
    },
    target: "normal",
    type: "Dragon",
    contestType: "Beautiful"
  })
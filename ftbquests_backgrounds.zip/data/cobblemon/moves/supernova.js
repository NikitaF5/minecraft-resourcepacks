({  num: 640031,
    accuracy: 100,
    basePower: 100,
    category: "Special",
    name: "Supernova",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    selfdestruct: "always",
    onBasePower(basePower, source) {
      if (this.field.isTerrain("psychicterrain") && source.isGrounded()) {
        this.debug("psychic terrain buff");
        return this.chainModify(1.5);
      }
    },
    secondary: null,
    target: "allAdjacent",
    type: "Psychic"
  })
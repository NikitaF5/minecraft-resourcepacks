({  num: 640010,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Disastrous Aura",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, pulse: 1 },
    secondary: {
      chance: 30,
      boosts: {
        spd: -1
      }
    },
    target: "allAdjacentFoes",
    type: "Dragon",
    contestType: "Clever"
  })
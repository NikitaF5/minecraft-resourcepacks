({  num: 640016,
    accuracy: 100,
    basePower: 100,
    category: "Physical",
    name: "Hypervoid Strike",
    pp: 5,
    priority: 0,
    flags: { metronome: 1, failencore: 1, nosleeptalk: 1, failcopycat: 1, failmimic: 1, failinstruct: 1, noparentalbond: 1, hyperstellar: 1 },
    noSketch: true,
    secondary: null,
    target: "normal",
    type: "Ghost"
  })
({  num: 640027,
    accuracy: 100,
    basePower: 85,
    category: "Special",
    name: "Starburst",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Rock",
    contestType: "Beautiful"
  })
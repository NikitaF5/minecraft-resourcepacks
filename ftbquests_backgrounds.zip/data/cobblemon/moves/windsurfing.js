({
    num: 69035,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Wind Surfing",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, wind: 1, distance: 1 },
    onBasePower(basePower, source) {
      if ((source.side.getSideCondition("tailwind"))) {
        return this.chainModify(1.5);
      }
    },
    secondary: null,
    target: "normal",
    type: "Flying"
  })
({  num: 640019,
    accuracy: 100,
    basePower: 60,
    category: "Physical",
    name: "Monkey Business",
    pp: 25,
    priority: 1,
    flags: { contact: 1, protect: 1, mirror: 1, failmefirst: 1, noassist: 1, failcopycat: 1 },
    onMoveFail(target, source, move) {
      source.addVolatile("confusion", source, move);
    },
    onAfterHit(target, source, move) {
      if (source.item || source.volatiles["gem"]) {
        return;
      }
      const yourItem = target.takeItem(source);
      if (!yourItem) {
        return;
      }
      if (!this.singleEvent("TakeItem", yourItem, target.itemState, source, target, move, yourItem) || !source.setItem(yourItem)) {
        target.item = yourItem.id;
        return;
      }
      this.add("-enditem", target, yourItem, "[silent]", "[from] move: Thief", "[of] " + source);
      this.add("-item", source, yourItem, "[from] move: Thief", "[of] " + target);
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Tough"
  })
({  num: 640004,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "Cataclysm",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      volatileStatus: "healblock"
    },
    target: "normal",
    type: "Ghost",
    contestType: "Cool"
  })
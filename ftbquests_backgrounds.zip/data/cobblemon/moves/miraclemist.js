({  num: 640017,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Miracle Mist",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 50,
      self: {
        boosts: {
          spd: 1
        }
      }
    },
    target: "allAdjacentFoes",
    type: "Water",
    contestType: "Beautiful"
  })
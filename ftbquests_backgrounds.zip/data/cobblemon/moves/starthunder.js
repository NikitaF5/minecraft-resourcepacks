({  num: 640029,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Star Thunder",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spa: 1
        }
      }
    },
    target: "normal",
    type: "Electric",
    contestType: "Cute"
  })